interface Window {
  Tally?: {
    loadEmbeds: () => void
  }
}
