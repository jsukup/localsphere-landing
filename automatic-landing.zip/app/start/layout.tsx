import type { ReactNode } from "react"

export default function StartLayout({ children }: { children: ReactNode }) {
  return children
}
